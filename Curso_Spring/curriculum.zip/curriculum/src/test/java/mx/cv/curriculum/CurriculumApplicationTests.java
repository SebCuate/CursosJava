package mx.cv.curriculum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurriculumApplicationTests {

	@Test
	void contextLoads() {
	}

}
